
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";

// Ensure the API key is available from the environment.
if (!process.env.API_KEY) {
  throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const fetchGroundedResponse = async (
  prompt: string,
  location: { latitude: number; longitude: number; }
): Promise<GenerateContentResponse> => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
        tools: [{ googleMaps: {} }],
        toolConfig: {
          retrievalConfig: {
            latLng: {
              latitude: location.latitude,
              longitude: location.longitude,
            },
          },
        },
      },
    });
    return response;
  } catch (error) {
    console.error("Error fetching from Gemini API:", error);
    if (error instanceof Error) {
        throw new Error(`Failed to fetch from Gemini API: ${error.message}`);
    }
    throw new Error("An unknown error occurred while fetching from the Gemini API.");
  }
};
