
export interface MapSource {
  uri: string;
  title: string;
}

export interface GroundingChunk {
  maps?: MapSource;
  web?: {
    uri: string;
    title: string;
  }
}
