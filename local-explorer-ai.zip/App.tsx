
import React, { useState, useEffect, useCallback } from 'react';
import { fetchGroundedResponse } from './services/geminiService';
import { GroundingChunk } from './types';
import SearchInput from './components/SearchInput';
import LoadingSpinner from './components/LoadingSpinner';
import ResultCard from './components/ResultCard';
import SourceLink from './components/SourceLink';
import ErrorAlert from './components/ErrorAlert';

const App: React.FC = () => {
  const [query, setQuery] = useState<string>('');
  const [response, setResponse] = useState<string | null>(null);
  const [sources, setSources] = useState<GroundingChunk[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [location, setLocation] = useState<{ latitude: number; longitude: number; } | null>(null);
  const [locationError, setLocationError] = useState<string | null>(null);

  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setLocation({
            latitude: position.coords.latitude,
            longitude: position.coords.longitude,
          });
          setLocationError(null);
        },
        (err) => {
          setLocationError(`Geolocation error: ${err.message}. Please enable location services in your browser.`);
          console.error(err);
        }
      );
    } else {
      setLocationError("Geolocation is not supported by this browser.");
    }
  }, []);

  const handleSearch = useCallback(async () => {
    if (!query.trim() || !location) {
      if (!location) {
        setError("Could not perform search because location is not available.");
      }
      return;
    }

    setIsLoading(true);
    setError(null);
    setResponse(null);
    setSources([]);

    try {
      const apiResponse = await fetchGroundedResponse(query, location);
      const text = apiResponse.text;
      setResponse(text);

      const groundingChunks = apiResponse.candidates?.[0]?.groundingMetadata?.groundingChunks ?? [];
      setSources(groundingChunks);

    } catch (err) {
      if (err instanceof Error) {
        setError(err.message);
      } else {
        setError("An unknown error occurred.");
      }
    } finally {
      setIsLoading(false);
    }
  }, [query, location]);
  
  const isLocationAvailable = location !== null;

  return (
    <div className="min-h-screen bg-slate-900 text-white flex flex-col items-center p-4 sm:p-6 lg:p-8">
      <div className="w-full max-w-4xl mx-auto flex flex-col items-center space-y-6">
        <header className="text-center space-y-2 pt-8 pb-4">
          <h1 className="text-4xl sm:text-5xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-sky-400 to-emerald-500">
            Local Explorer AI
          </h1>
          <p className="text-slate-400 max-w-2xl">
            Get intelligent, location-aware answers powered by Gemini. Ask about places nearby and get results grounded in Google Maps.
          </p>
        </header>

        <main className="w-full flex flex-col items-center space-y-6">
          <SearchInput 
            query={query} 
            setQuery={setQuery} 
            onSearch={handleSearch} 
            isLoading={isLoading}
            isLocationAvailable={isLocationAvailable}
          />
          
          {locationError && <ErrorAlert message={locationError} />}

          {isLoading && <LoadingSpinner />}
          {error && !isLoading && <ErrorAlert message={error} />}
          
          <div className="w-full max-w-2xl space-y-6">
            {response && !isLoading && <ResultCard text={response} />}
            
            {sources.length > 0 && !isLoading && (
              <div className="space-y-4">
                <h3 className="text-lg font-semibold text-slate-300">Sources from Google Maps</h3>
                <div className="grid grid-cols-1 gap-3">
                  {sources.map((source, index) => (
                    <SourceLink key={index} source={source} />
                  ))}
                </div>
              </div>
            )}
            
            {!isLoading && !response && !locationError && (
                 <div className="text-center text-slate-500 pt-8">
                    <p>📍 Location acquired. Ask a question to get started!</p>
                </div>
            )}
          </div>
        </main>
        
        <footer className="w-full text-center py-8 mt-auto">
            <a href="https://www.google.com/maps" target="_blank" rel="noopener noreferrer" className="text-sm text-slate-500 hover:text-sky-400 transition-colors">
                Powered by Google Maps Data
            </a>
        </footer>
      </div>
    </div>
  );
};

export default App;
