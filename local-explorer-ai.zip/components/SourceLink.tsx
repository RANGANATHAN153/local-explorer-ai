
import React from 'react';
import { GroundingChunk } from '../types';

interface SourceLinkProps {
  source: GroundingChunk;
}

const SourceLink: React.FC<SourceLinkProps> = ({ source }) => {
  const mapSource = source.maps;
  if (!mapSource) return null;

  return (
    <a
      href={mapSource.uri}
      target="_blank"
      rel="noopener noreferrer"
      className="flex items-center space-x-3 bg-slate-800 hover:bg-slate-700 p-3 rounded-lg transition duration-200 border border-slate-700"
    >
      <div className="flex-shrink-0">
        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-emerald-400" viewBox="0 0 20 20" fill="currentColor">
          <path fillRule="evenodd" d="M5.05 4.05a7 7 0 119.9 9.9L10 18.9l-4.95-4.95a7 7 0 010-9.9zM10 11a2 2 0 100-4 2 2 0 000 4z" clipRule="evenodd" />
        </svg>
      </div>
      <div className="flex-grow">
        <p className="font-medium text-sky-400">{mapSource.title}</p>
        <p className="text-xs text-slate-500 truncate">{mapSource.uri}</p>
      </div>
       <div className="flex-shrink-0">
         <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-slate-500" viewBox="0 0 20 20" fill="currentColor">
          <path d="M11 3a1 1 0 100 2h2.586l-6.293 6.293a1 1 0 101.414 1.414L15 6.414V9a1 1 0 102 0V4a1 1 0 00-1-1h-5z" />
          <path d="M5 5a2 2 0 00-2 2v8a2 2 0 002 2h8a2 2 0 002-2v-3a1 1 0 10-2 0v3H5V7h3a1 1 0 000-2H5z" />
        </svg>
       </div>
    </a>
  );
};

export default SourceLink;
