
import React from 'react';

interface ResultCardProps {
  text: string;
}

const ResultCard: React.FC<ResultCardProps> = ({ text }) => {
  return (
    <div className="bg-slate-800/50 border border-slate-700 rounded-lg p-6 w-full max-w-2xl space-y-4">
      <h2 className="text-xl font-semibold text-sky-300">AI Response</h2>
      <p className="text-slate-300 whitespace-pre-wrap">{text}</p>
    </div>
  );
};

export default ResultCard;
