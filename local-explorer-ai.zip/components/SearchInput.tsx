
import React from 'react';

interface SearchInputProps {
  query: string;
  setQuery: (query: string) => void;
  onSearch: () => void;
  isLoading: boolean;
  isLocationAvailable: boolean;
}

const SearchInput: React.FC<SearchInputProps> = ({ query, setQuery, onSearch, isLoading, isLocationAvailable }) => {
  const handleKeyDown = (event: React.KeyboardEvent<HTMLInputElement>) => {
    if (event.key === 'Enter') {
      onSearch();
    }
  };

  return (
    <div className="flex w-full max-w-2xl items-center space-x-2">
      <input
        type="text"
        value={query}
        onChange={(e) => setQuery(e.target.value)}
        onKeyDown={handleKeyDown}
        placeholder="e.g., 'What are the best coffee shops nearby?'"
        className="flex-grow bg-slate-800 text-white placeholder-slate-500 border border-slate-700 rounded-lg p-3 focus:ring-2 focus:ring-sky-500 focus:outline-none transition duration-200 disabled:opacity-50"
        disabled={isLoading || !isLocationAvailable}
      />
      <button
        onClick={onSearch}
        disabled={isLoading || !isLocationAvailable || !query.trim()}
        className="bg-sky-600 text-white font-semibold px-6 py-3 rounded-lg hover:bg-sky-500 focus:outline-none focus:ring-2 focus:ring-sky-500 focus:ring-offset-2 focus:ring-offset-slate-900 disabled:bg-slate-600 disabled:cursor-not-allowed transition duration-200 flex items-center justify-center"
      >
        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
          <path fillRule="evenodd" d="M8 4a4 4 0 100 8 4 4 0 000-8zM2 8a6 6 0 1110.89 3.476l4.817 4.817a1 1 0 01-1.414 1.414l-4.816-4.816A6 6 0 012 8z" clipRule="evenodd" />
        </svg>
      </button>
    </div>
  );
};

export default SearchInput;
